function Header() {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);
    
    const handleNavigation = (href) => {
      if (href.startsWith('#')) {
        const element = document.getElementById(href.substring(1));
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        } else {
          window.location.href = `index.html${href}`;
        }
      } else {
        window.location.href = href;
      }
    };

    return (
      <header className="fixed top-0 w-full z-40 bg-[var(--bg-dark)]/80 backdrop-blur-md border-b border-[var(--border-color)]" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] flex items-center justify-center">
                <div className="icon-rocket text-white text-xl"></div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gradient">NASA Bioscience Lab</h1>
                <p className="text-xs text-[var(--text-gray)]">Space Apps Challenge 2025</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-2">
              <button onClick={() => handleNavigation('index.html')} className="nav-link">Home</button>
              <button onClick={() => handleNavigation('search.html')} className="nav-link">Search & Explore</button>
              <button onClick={() => handleNavigation('about.html')} className="nav-link">About</button>
              <button onClick={() => handleNavigation('insights.html')} className="nav-link">Insights</button>
              <button onClick={() => handleNavigation('resources.html')} className="nav-link">Resources</button>
              <button onClick={() => handleNavigation('contact.html')} className="nav-link">Contact</button>

            </nav>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-white/10"
            >
              <div className={`icon-${isMenuOpen ? 'x' : 'menu'} text-xl text-[var(--text-light)]`}></div>
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <nav className="md:hidden mt-4 pb-4 border-t border-[var(--border-color)] pt-4">
              <div className="flex flex-col space-y-2">
                <button onClick={() => handleNavigation('index.html')} className="nav-link text-left">Home</button>
                <button onClick={() => handleNavigation('search.html')} className="nav-link text-left">Search & Explore</button>
                <button onClick={() => handleNavigation('about.html')} className="nav-link text-left">About</button>
                <button onClick={() => handleNavigation('insights.html')} className="nav-link text-left">Insights</button>
                <button onClick={() => handleNavigation('resources.html')} className="nav-link text-left">Resources</button>
                <button onClick={() => handleNavigation('contact.html')} className="nav-link text-left">Contact</button>

              </div>
            </nav>
          )}
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}