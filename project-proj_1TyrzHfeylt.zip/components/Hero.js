function Hero() {
  try {
    return (
      <section className="pt-24 pb-16 px-4" data-name="hero" data-file="components/Hero.js">
        <div className="container mx-auto text-center max-w-4xl">
          <div className="mb-8">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gradient">
              NASA Bioscience Lab Dashboard
            </h1>
            <p className="text-xl md:text-2xl text-[var(--text-gray)] mb-8 leading-relaxed">
              Exploring the frontiers of space biology to support human missions to the Moon and Mars
            </p>
          </div>

          <div className="card max-w-3xl mx-auto mb-12">
            <h2 className="text-2xl font-semibold mb-4 text-[var(--text-light)]">Our Mission</h2>
            <p className="text-lg text-[var(--text-gray)] leading-relaxed">
              We summarize and analyze NASA's bioscience research to understand how living organisms adapt to space environments. 
              Our comprehensive database contains 608 publications covering human physiology, plant biology, microbiology, 
              and radiation effects—critical knowledge for ensuring astronaut health and mission success on long-duration space flights.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button 
              onClick={() => window.location.href = 'search.html'}
              className="btn-primary text-lg px-8 py-4"
            >
              <div className="flex items-center space-x-2">
                <div className="icon-search text-xl"></div>
                <span>Explore Research</span>
              </div>
            </button>
            <button 
              onClick={() => window.location.href = 'insights.html'}
              className="btn-secondary text-lg px-8 py-4"
            >
              <div className="flex items-center space-x-2">
                <div className="icon-chart-bar text-xl"></div>
                <span>View Insights</span>
              </div>
            </button>
          </div>

          <div className="mt-12 text-sm text-[var(--text-gray)] bg-[var(--primary-color)]/10 rounded-lg p-4 border border-[var(--primary-color)]/20">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="icon-info text-[var(--secondary-color)]"></div>
              <span className="font-medium">Data Sources</span>
            </div>
            Data sourced from official NASA repositories (Task Book, NSLSL, OSDR, and SB_Publications)
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}