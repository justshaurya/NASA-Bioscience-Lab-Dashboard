function RecentStudies() {
  try {
    const [studies, setStudies] = React.useState([]);

    React.useEffect(() => {
      // Load sample recent studies
      if (window.sampleData && window.sampleData.recentStudies) {
        setStudies(window.sampleData.recentStudies);
      }
    }, []);

    const handleStudyClick = (studyId) => {
      window.location.href = `project.html?id=${studyId}`;
    };

    return (
      <section id="recent-studies" className="py-16 px-4 bg-gradient-to-b from-transparent to-black/20" data-name="recent-studies" data-file="components/RecentStudies.js">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gradient">Recent NASA Bioscience Studies</h2>
            <p className="text-lg text-[var(--text-gray)] max-w-2xl mx-auto">
              Discover the latest breakthroughs in space biology research from recent NASA missions and experiments
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {studies.slice(0, 9).map((study, index) => (
              <div 
                key={study.id || index}
                onClick={() => handleStudyClick(study.id)}
                className="tool-card group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-[var(--text-light)] mb-2 line-clamp-2 group-hover:text-[var(--primary-color)] transition-colors">
                      {study.title}
                    </h3>
                  </div>
                  <span className="bg-[var(--primary-color)]/20 text-[var(--primary-color)] px-2 py-1 rounded-lg text-xs font-medium ml-2">
                    {study.year}
                  </span>
                </div>
                
                <div className="space-y-2 text-sm text-[var(--text-gray)]">
                  <div className="flex items-center space-x-2">
                    <div className="icon-user text-[var(--secondary-color)]"></div>
                    <span className="truncate">{study.authors}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="icon-tag text-[var(--accent-color)]"></div>
                    <span className="bg-[var(--accent-color)]/20 text-[var(--accent-color)] px-2 py-1 rounded text-xs">
                      {study.category}
                    </span>
                  </div>
                  {study.mission && (
                    <div className="flex items-center space-x-2">
                      <div className="icon-rocket text-[var(--secondary-color)]"></div>
                      <span>{study.mission}</span>
                    </div>
                  )}
                </div>
                
                <div className="mt-4 pt-3 border-t border-[var(--border-color)]">
                  <div className="flex items-center text-[var(--primary-color)] text-sm group-hover:text-[var(--secondary-color)] transition-colors">
                    <span>Read Full Study</span>
                    <div className="icon-arrow-right ml-1 text-sm transform group-hover:translate-x-1 transition-transform"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-10">
            <button 
              onClick={() => window.location.href = 'search.html'}
              className="btn-secondary"
            >
              View All Studies
            </button>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('RecentStudies component error:', error);
    return null;
  }
}