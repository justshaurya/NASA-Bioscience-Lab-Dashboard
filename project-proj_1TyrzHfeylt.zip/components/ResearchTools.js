function ResearchTools() {
  try {
    const handleToolClick = (toolId) => {
      const toolRoutes = {
        'tool-advanced-search': 'tools/advanced-search.html',
        'tool-kg': 'tools/knowledge-graph.html',
        'tool-timeline': 'tools/research-timeline.html',
        'tool-export': 'tools/export.html',
        'tool-human': 'tools/human-health.html',
        'tool-plant': 'tools/plant-microbiology.html'
      };
      
      if (toolRoutes[toolId]) {
        window.location.href = toolRoutes[toolId];
      }
    };

    const tools = [
      {
        id: 'tool-advanced-search',
        title: 'Advanced Search',
        description: 'Search across all studies with advanced filters',
        icon: 'search',
        color: 'var(--primary-color)'
      },
      {
        id: 'tool-kg',
        title: 'Knowledge Graphs',
        description: 'Interactive visualization of research connections',
        icon: 'network',
        color: 'var(--secondary-color)'
      },
      {
        id: 'tool-timeline',
        title: 'Research Timeline',
        description: 'Explore publications chronologically',
        icon: 'calendar',
        color: 'var(--accent-color)'
      },
      {
        id: 'tool-export',
        title: 'Export Data',
        description: 'Download research data in various formats',
        icon: 'download',
        color: '#10b981'
      },
      {
        id: 'tool-human',
        title: 'Human Health Research',
        description: 'Focus on astronaut physiology and health',
        icon: 'heart',
        color: '#f59e0b'
      },
      {
        id: 'tool-plant',
        title: 'Plant & Microbiology',
        description: 'Study plant growth and microbial behavior',
        icon: 'leaf',
        color: '#06d6a0'
      }
    ];

    return (
      <section id="research-tools" className="py-16 px-4" data-name="research-tools" data-file="components/ResearchTools.js">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gradient">Research Tools</h2>
            <p className="text-lg text-[var(--text-gray)] max-w-2xl mx-auto">
              Powerful tools to explore, analyze, and extract insights from NASA's bioscience research database
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool) => (
              <div 
                key={tool.id}
                id={tool.id}
                onClick={() => handleToolClick(tool.id)}
                className="tool-card group"
              >
                <div className="flex items-start space-x-4">
                  <div 
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${tool.color}20` }}
                  >
                    <div 
                      className={`icon-${tool.icon} text-xl`}
                      style={{ color: tool.color }}
                    ></div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-[var(--text-light)] mb-2 group-hover:text-[var(--primary-color)] transition-colors">
                      {tool.title}
                    </h3>
                    <p className="text-[var(--text-gray)] text-sm leading-relaxed">
                      {tool.description}
                    </p>
                  </div>
                </div>
                
                <div className="mt-4 pt-3 border-t border-[var(--border-color)]">
                  <div className="flex items-center text-[var(--primary-color)] text-sm group-hover:text-[var(--secondary-color)] transition-colors">
                    <span>Open Tool</span>
                    <div className="icon-arrow-right ml-1 text-sm transform group-hover:translate-x-1 transition-transform"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal for tools */}
        <div id="tool-modal" className="modal">
          <div className="modal-inner">
            <button 
              id="modal-close" 
              className="absolute top-4 right-4 text-[var(--text-gray)] hover:text-[var(--text-light)] text-2xl"
              aria-label="Close modal"
            >
              ✕
            </button>
            <h2 id="modal-title" className="text-2xl font-bold mb-4 text-[var(--text-light)]"></h2>
            <div id="modal-body" className="text-[var(--text-gray)]"></div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('ResearchTools component error:', error);
    return null;
  }
}