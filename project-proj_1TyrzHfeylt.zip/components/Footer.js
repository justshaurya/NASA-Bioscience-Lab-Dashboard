function Footer() {
  try {
    return (
      <footer className="bg-[var(--bg-darker)] border-t border-[var(--border-color)] py-12 px-4" data-name="footer" data-file="components/Footer.js">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Project Info */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] flex items-center justify-center">
                  <div className="icon-rocket text-white text-xl"></div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[var(--text-light)]">NASA Bioscience Lab</h3>
                  <p className="text-xs text-[var(--text-gray)]">Space Apps Challenge 2025</p>
                </div>
              </div>
              <p className="text-[var(--text-gray)] text-sm leading-relaxed">
                Advancing space exploration through comprehensive bioscience research analysis and data visualization.
              </p>
            </div>

            {/* Team Galactic */}
            <div>
              <h4 className="font-semibold text-[var(--text-light)] mb-3">Team Galactic</h4>
              <p className="text-[var(--text-gray)] text-sm mb-4">
                Participants in the NASA Space Apps Challenge 2025, dedicated to making space biology research accessible and actionable.
              </p>
              <div className="space-y-2 text-sm">
                <a href="#" className="text-[var(--primary-color)] hover:text-[var(--secondary-color)] transition-colors">
                  NASA Space Apps Project →
                </a>
                <br />
                <a href="https://github.com/team-galactic" target="_blank" className="text-[var(--primary-color)] hover:text-[var(--secondary-color)] transition-colors">
                  GitHub Repository →
                </a>
                <br />
                <a href="mailto:teamgalactic@gmail.com" className="text-[var(--primary-color)] hover:text-[var(--secondary-color)] transition-colors">
                  Contact Us →
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold text-[var(--text-light)] mb-3">Quick Links</h4>
              <div className="space-y-2 text-sm">
                <button 
                  onClick={() => window.location.href = 'search.html'} 
                  className="block text-[var(--text-gray)] hover:text-[var(--text-light)] transition-colors"
                >
                  Search & Explore
                </button>
                <button 
                  onClick={() => window.location.href = 'insights.html'} 
                  className="block text-[var(--text-gray)] hover:text-[var(--text-light)] transition-colors"
                >
                  AI Insights
                </button>
                <button 
                  onClick={() => window.location.href = 'resources.html'} 
                  className="block text-[var(--text-gray)] hover:text-[var(--text-light)] transition-colors"
                >
                  NASA Resources
                </button>
                <button 
                  onClick={() => window.location.href = 'about.html'} 
                  className="block text-[var(--text-gray)] hover:text-[var(--text-light)] transition-colors"
                >
                  About Project
                </button>
              </div>
            </div>
          </div>

          <div className="border-t border-[var(--border-color)] mt-8 pt-8 text-center text-sm text-[var(--text-gray)]">
            <p>© 2025 Team Galactic - NASA Space Apps Challenge. All rights reserved.</p>
            <p className="mt-2">
              This project is an AI-generated representation of NASA bioscience data for educational and research purposes.
            </p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}