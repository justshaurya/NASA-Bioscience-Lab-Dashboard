When project updates are made:
- Check if README.md in trickle/notes needs updating
- Update feature list when new functionality is added
- Update technology stack when dependencies change
- Update database schema when data structure changes
- Update pages structure when new HTML files are added
- Update database status when sample data changes
- Update last modified date to current date
- Ensure all tool implementations are documented
