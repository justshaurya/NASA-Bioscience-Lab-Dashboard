# NASA Bioscience Lab Dashboard

## Project Overview
A comprehensive web application for exploring NASA's bioscience research publications and experiments, built for the NASA Space Apps Challenge 2025.

## Features
- **Search & Explore**: Advanced search functionality across NASA bioscience publications with filters
- **Research Tools**: Six specialized tools for data analysis and visualization
  - Advanced Search Tool
  - Knowledge Graph Visualization
  - Research Timeline with charts
  - Data Export functionality
  - Human Health Research focus
  - Plant & Microbiology studies
- **AI Insights**: Automated analysis and trend detection from research data with Chart.js visualizations
- **Project Pages**: Detailed pages for each research publication with dynamic loading
- **Multi-page Structure**: Separate HTML files for different sections (About, Resources, Contact)

## Data Sources
- NASA Task Book
- NASA Space Life Sciences Library (NSLSL)
- NASA Open Science Data Repository (OSDR)
- NASA Bioscience Publications GitHub Repository

## Technology Stack
- React 18 for UI components
- TailwindCSS for styling with custom theme variables
- Chart.js for data visualization and insights
- Trickle Database for data storage and queries
- Lucide icons for interface elements

## Database Schema
The `publications` table contains 14 fields:
- title, authors, year, category, mission
- abstract, doi, keywords, pi, affiliation
- source_url, status, slug, raw_row

Current database contains sample publications for Human Physiology, Plant Biology, and Microbiology research.

## Pages Structure
- `index.html` - Main dashboard homepage
- `search.html` - Search and explore publications
- `about.html` - Project information and mission
- `resources.html` - NASA data sources and links
- `contact.html` - Team Galactic contact information
- `insights.html` - AI-powered analysis and charts
- `project.html` - Individual publication details
- `tools/` - Six research tool pages
- `preview.html` - System status and import preview

## Team Galactic
NASA Space Apps Challenge 2025 participants dedicated to making space biology research accessible and actionable.

Last updated: 2025-10-05
