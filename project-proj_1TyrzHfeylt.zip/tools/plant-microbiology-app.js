function PlantMicrobiologyPage() {
  const [studies, setStudies] = React.useState([]);
  const [activeFilter, setActiveFilter] = React.useState('all');
  
  const filterTags = [
    { id: 'all', label: 'All Studies' },
    { id: 'plant', label: 'Plant Growth' },
    { id: 'microbe', label: 'Microbiology' }
  ];

  React.useEffect(() => {
    loadPlantMicroData();
  }, []);

  const loadPlantMicroData = async () => {
    try {
      const data = await trickleListObjects('publications', 100);
      const filtered = data.items.filter(item => {
        const category = item.objectData.category?.toLowerCase() || '';
        const title = item.objectData.title?.toLowerCase() || '';
        
        return category.includes('plant') || category.includes('micro') ||
               title.includes('plant') || title.includes('microb');
      });
      
      setStudies(filtered);
    } catch (error) {
      setStudies([
        { objectId: '1', objectData: { title: 'Arabidopsis in Microgravity', category: 'Plant Biology', year: 2024 } }
      ]);
    }
  };

  const filteredStudies = studies.filter(study => {
    if (activeFilter === 'all') return true;
    const title = study.objectData.title?.toLowerCase() || '';
    const category = study.objectData.category?.toLowerCase() || '';
    
    return activeFilter === 'plant' ? 
      (title.includes('plant') || category.includes('plant')) :
      (title.includes('microb') || category.includes('micro'));
  });

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-8 text-center" 
              style={{background: 'linear-gradient(135deg, var(--primary-color), var(--secondary-color))', 
                      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
            Plant & Microbiology Research
          </h1>
          
          <div className="card mb-8">
            <h2 className="text-xl font-bold mb-4">Filter Studies</h2>
            <div className="flex gap-3">
              {filterTags.map(tag => (
                <button
                  key={tag.id}
                  onClick={() => setActiveFilter(tag.id)}
                  className={`px-3 py-1 rounded text-sm ${
                    activeFilter === tag.id ? 'bg-[var(--secondary-color)] text-white' : 'bg-gray-600 text-gray-300'
                  }`}
                >
                  {tag.label}
                </button>
              ))}
            </div>
          </div>

          <div className="card">
            <h2 className="text-xl font-bold mb-4">Studies ({filteredStudies.length})</h2>
            <div className="space-y-4">
              {filteredStudies.map((study, index) => (
                <div key={study.objectId || index} className="p-4 bg-[var(--bg-dark)] rounded-lg">
                  <h3 className="font-medium text-white">{study.objectData.title}</h3>
                  <p className="text-[var(--text-gray)] text-sm">{study.objectData.category} • {study.objectData.year}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PlantMicrobiologyPage />);