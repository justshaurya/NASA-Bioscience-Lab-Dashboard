function ExportPage() {
  const [format, setFormat] = React.useState('csv');
  const [data, setData] = React.useState([]);
  
  React.useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const result = await trickleListObjects('publications', 100);
      setData(result.items);
    } catch (error) {
      setData([]);
    }
  };

  const downloadCSV = () => {
    const headers = 'Title,Authors,Year,Category,Mission,DOI\n';
    const csvData = data.map(item => {
      const d = item.objectData;
      return `"${d.title || ''}","${(d.authors || []).join('; ')}","${d.year || ''}","${d.category || ''}","${d.mission || ''}","${d.doi || ''}"`;
    }).join('\n');
    
    const blob = new Blob([headers + csvData], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nasa_bioscience_publications.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExport = () => {
    if (format === 'csv') downloadCSV();
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h1 className="text-4xl font-bold mb-8 text-center" 
              style={{background: 'linear-gradient(135deg, var(--primary-color), var(--secondary-color))', 
                      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
            Export Data
          </h1>
          
          <div className="card mb-8">
            <h2 className="text-xl font-bold mb-4">Export Options</h2>
            <button onClick={handleExport} className="bg-[var(--primary-color)] text-white px-6 py-3 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="icon-download text-xl"></div>
                <span>Export CSV ({data.length} records)</span>
              </div>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ExportPage />);