function AdvancedSearchPage() {
  const [query, setQuery] = React.useState('');
  const [results, setResults] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  
  const handleSearch = async () => {
    setLoading(true);
    try {
      const data = await trickleListObjects('publications', 50);
      setResults(data.items.filter(item => 
        item.objectData.title?.toLowerCase().includes(query.toLowerCase())
      ));
    } catch (error) {
      setResults([]);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-8 text-center" 
              style={{background: 'linear-gradient(135deg, var(--primary-color), var(--secondary-color))', 
                      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
            Advanced Search
          </h1>
          
          <div className="card mb-8">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter search query..."
              className="w-full p-3 bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-lg text-white"
            />
            <button onClick={handleSearch} className="mt-4 bg-[var(--primary-color)] text-white px-6 py-3 rounded-lg">
              Search Publications
            </button>
          </div>

          <div className="card">
            <h2 className="text-xl font-bold mb-4">Results ({results.length})</h2>
            {loading && <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[var(--primary-color)]"></div>}
            <div className="space-y-4">
              {results.map(item => (
                <div key={item.objectId} className="p-4 bg-[var(--bg-dark)] rounded-lg">
                  <h3 className="font-semibold text-white">{item.objectData.title}</h3>
                  <p className="text-[var(--text-gray)] text-sm">{item.objectData.category} • {item.objectData.year}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AdvancedSearchPage />);