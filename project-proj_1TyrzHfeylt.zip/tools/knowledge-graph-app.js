function KnowledgeGraphPage() {
  const [nodes, setNodes] = React.useState([]);
  
  React.useEffect(() => {
    loadGraphData();
  }, []);

  const loadGraphData = async () => {
    try {
      const data = await trickleListObjects('publications', 20);
      const graphNodes = data.items.map(item => ({
        id: item.objectId,
        label: item.objectData.title,
        category: item.objectData.category
      }));
      setNodes(graphNodes);
    } catch (error) {
      setNodes([
        { id: '1', label: 'Bone Loss Studies', category: 'Human Physiology' },
        { id: '2', label: 'Plant Growth Research', category: 'Plant Biology' },
        { id: '3', label: 'Radiation Effects', category: 'Radiation Biology' }
      ]);
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-8 text-center" 
              style={{background: 'linear-gradient(135deg, var(--primary-color), var(--secondary-color))', 
                      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
            Knowledge Graph
          </h1>
          
          <div className="card mb-8">
            <h2 className="text-xl font-bold mb-4">Research Network Visualization</h2>
            <div className="bg-[var(--bg-dark)] rounded-lg p-8 min-h-[400px] flex items-center justify-center">
              <div className="text-center">
                <div className="icon-network text-6xl text-[var(--primary-color)] mb-4"></div>
                <p className="text-[var(--text-gray)]">Interactive graph visualization loading...</p>
                <p className="text-sm text-[var(--text-gray)] mt-2">Showing {nodes.length} research nodes</p>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-lg font-bold mb-4">Connected Research Topics</h3>
            <div className="grid md:grid-cols-3 gap-4">
              {nodes.map(node => (
                <div key={node.id} className="p-3 bg-[var(--bg-dark)] rounded-lg">
                  <div className="font-medium text-white text-sm">{node.label}</div>
                  <div className="text-xs text-[var(--text-gray)]">{node.category}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<KnowledgeGraphPage />);