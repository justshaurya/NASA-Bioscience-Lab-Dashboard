function HumanHealthPage() {
  const [healthStudies, setHealthStudies] = React.useState([]);
  const [analytics, setAnalytics] = React.useState({});
  
  React.useEffect(() => {
    loadHealthData();
  }, []);

  const loadHealthData = async () => {
    try {
      const data = await trickleListObjects('publications', 100);
      const healthKeywords = ['bone', 'muscle', 'immune', 'radiation', 'cardiovascular'];
      
      const filtered = data.items.filter(item => {
        const category = item.objectData.category?.toLowerCase() || '';
        const title = item.objectData.title?.toLowerCase() || '';
        
        return category.includes('physiology') || 
               healthKeywords.some(kw => title.includes(kw));
      });
      
      setHealthStudies(filtered);
      setAnalytics({ total: filtered.length });
    } catch (error) {
      setHealthStudies([
        { objectId: '1', objectData: { title: 'Bone Loss in Microgravity', category: 'Human Physiology', year: 2024 } }
      ]);
      setAnalytics({ total: 1 });
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-8 text-center" 
              style={{background: 'linear-gradient(135deg, var(--primary-color), var(--secondary-color))', 
                      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
            Human Health Research
          </h1>
          
          <div className="card mb-8">
            <h2 className="text-xl font-bold mb-4">AI Summary</h2>
            <div className="bg-[var(--primary-color)]/10 border border-[var(--primary-color)]/20 rounded-lg p-4">
              <p className="text-[var(--text-gray)]">
                Human health research focuses on astronaut physiology during long-duration missions, 
                including bone loss, immune response, and radiation effects.
              </p>
            </div>
          </div>

          <div className="card">
            <h2 className="text-xl font-bold mb-4">Studies ({healthStudies.length})</h2>
            <div className="space-y-4">
              {healthStudies.map((study, index) => (
                <div key={study.objectId || index} className="p-4 bg-[var(--bg-dark)] rounded-lg">
                  <h3 className="font-medium text-white">{study.objectData.title}</h3>
                  <p className="text-[var(--text-gray)] text-sm">{study.objectData.category} • {study.objectData.year}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<HumanHealthPage />);