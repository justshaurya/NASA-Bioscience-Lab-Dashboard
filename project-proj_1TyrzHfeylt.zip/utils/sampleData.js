// Sample data for NASA Bioscience Dashboard
window.sampleData = {
  // Recent studies for homepage
  recentStudies: [
    {
      id: 'exp-hp-2024-01',
      title: 'Bone Density Changes in Long-Duration Spaceflight',
      authors: 'Dr. Sarah Chen, Dr. Michael Rodriguez',
      year: 2024,
      category: 'Human Physiology',
      mission: 'ISS Expedition 70',
      abstract: 'Comprehensive study of bone mineral density changes in astronauts during 6-month ISS missions.'
    },
    {
      id: 'exp-pb-2024-02',
      title: 'Arabidopsis Growth Patterns in Microgravity Environments',
      authors: 'Dr. Emily Watson, Dr. James Park',
      year: 2024,
      category: 'Plant Biology',
      mission: 'ISS Advanced Plant Habitat',
      abstract: 'Analysis of root and shoot development in Arabidopsis thaliana under microgravity conditions.'
    },
    {
      id: 'exp-mb-2023-15',
      title: 'Immune System Response to Space Radiation',
      authors: 'Dr. David Liu, Dr. Anna Kowalski',
      year: 2023,
      category: 'Human Physiology',
      mission: 'Artemis Mission Prep',
      abstract: 'Investigation of T-cell and B-cell responses to cosmic radiation exposure.'
    },
    {
      id: 'exp-mi-2023-12',
      title: 'Microbial Behavior in Closed-Loop Life Support Systems',
      authors: 'Dr. Maria Santos, Dr. Robert Johnson',
      year: 2023,
      category: 'Microbiology',
      mission: 'ISS Expedition 69',
      abstract: 'Study of bacterial and fungal growth patterns in spacecraft environments.'
    }
  ],
  
  // Sample data for tools and searches
  searchSample: [
    {id:'S1', title:'Bone density in microgravity', year:2018, doi:'https://doi.org/10.x/abc', category:'Human Physiology'},
    {id:'S2', title:'Plant growth in space stations', year:2020, doi:'https://doi.org/10.x/def', category:'Plant Biology'},
    {id:'S3', title:'Radiation effects on DNA', year:2019, doi:'https://doi.org/10.x/ghi', category:'Radiation Biology'}
  ],
  
  humanSample: [
    {id:'H1', title:'Immune changes in astronauts', summary:'Decreased T-cell activity in microgravity', doi:'https://doi.org/10.x/def', category:'Human Physiology'},
    {id:'H2', title:'Cardiovascular adaptation to space', summary:'Heart muscle changes during long missions', doi:'https://doi.org/10.x/xyz', category:'Human Physiology'}
  ],
  
  plantSample: [
    {id:'P1', title:'Arabidopsis growth in space', summary:'Altered root growth patterns', doi:'https://doi.org/10.x/ghi', category:'Plant Biology'},
    {id:'P2', title:'Wheat cultivation in microgravity', summary:'Grain production challenges in space', doi:'https://doi.org/10.x/jkl', category:'Plant Biology'}
  ],
  
  timelineSample: [
    {year:2015,count:5},{year:2016,count:8},{year:2017,count:12},{year:2018,count:9},
    {year:2019,count:15},{year:2020,count:18},{year:2021,count:22},{year:2022,count:25},
    {year:2023,count:28},{year:2024,count:30}
  ]
};

// Tool click handlers
const sampleData = window.sampleData;

function openModal(title, htmlContent) {
  let modal = document.getElementById('tool-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id='tool-modal';
    modal.className='modal';
    modal.innerHTML = `<div class="modal-inner" role="dialog" aria-modal="true"><button id="modal-close" aria-label="Close modal">✕</button><h2 id="modal-title"></h2><div id="modal-body"></div></div>`;
    document.body.appendChild(modal);
    document.getElementById('modal-close').addEventListener('click', closeModal);
    document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeModal(); });
  }
  document.getElementById('modal-title').innerText = title;
  document.getElementById('modal-body').innerHTML = htmlContent;
  modal.style.display='flex';
  document.getElementById('modal-close').focus();
}

function closeModal(){
  const m=document.getElementById('tool-modal');
  if(m) m.style.display='none';
}

// Initialize tool handlers when DOM loads
document.addEventListener('DOMContentLoaded', ()=>{
  const mapping = {
    'tool-advanced-search': ()=> window.location.href = 'search.html',
    'tool-kg': ()=> openModal('Knowledge Graphs', `<p>Interactive graph of topics and papers.</p><div id="kg-canvas">Loading sample graph...</div><button id="load-kg-sample" class="btn-primary mt-4">Load Sample Graph</button>`),
    'tool-timeline': ()=> openModal('Research Timeline', `<canvas id="timeline-chart" width="600" height="300"></canvas><button id="load-timeline" class="btn-primary mt-4">Load Timeline</button>`),
    'tool-export': ()=> openModal('Export Data', `<p>Export current results as CSV/PDF.</p><button id="download-sample-csv" class="btn-primary mt-4">Download Sample CSV</button>`),
    'tool-human': ()=> openModal('Human Health Research', `<div id="human-list"></div><button id="load-human" class="btn-primary mt-4">Load Human Studies</button>`),
    'tool-plant': ()=> openModal('Plant & Microbiology', `<div id="plant-list"></div><button id="load-plant" class="btn-primary mt-4">Load Plant Studies</button>`)
  };
  
  Object.keys(mapping).forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.addEventListener('click', mapping[id]);
  });
  
  document.body.addEventListener('click', (e)=>{
    if(e.target.id==='load-kg-sample'){
      document.getElementById('kg-canvas').innerHTML='<div class="bg-gray-800 p-4 rounded"><p>Sample Knowledge Graph:</p><ul><li>Human Physiology → Bone Studies → Microgravity</li><li>Plant Biology → Growth Patterns → Space Environment</li><li>Radiation → DNA Effects → Astronaut Health</li></ul></div>';
    }
    if(e.target.id==='load-timeline'){
      const c=document.getElementById('timeline-chart');
      if(c && c.getContext){
        const ctx=c.getContext('2d');
        ctx.clearRect(0,0,600,300);
        ctx.fillStyle='rgba(79, 70, 229, 0.8)';
        sampleData.timelineSample.forEach((d,i)=>{
          ctx.fillRect(50*i+20, 280 - d.count*8, 30, d.count*8);
          ctx.fillStyle='rgba(241, 245, 249, 0.9)';
          ctx.font = '12px Arial';
          ctx.fillText(d.year,50*i+15,295);
          ctx.fillStyle='rgba(79, 70, 229, 0.8)';
        });
      }
    }
    if(e.target.id==='download-sample-csv'){
      const csv='title,year,doi,category\nBone density in microgravity,2018,https://doi.org/10.x/abc,Human Physiology\nPlant growth in space stations,2020,https://doi.org/10.x/def,Plant Biology';
      const a=document.createElement('a');
      a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(csv);
      a.download='sample_publications.csv';
      a.click();
    }
    if(e.target.id==='load-human'){
      document.getElementById('human-list').innerHTML='<ul class="space-y-2">'+sampleData.humanSample.map(s=>`<li class="p-3 bg-gray-800 rounded"><b>${s.title}</b><br/><span class="text-gray-400">${s.summary}</span><br/><a href="${s.doi}" target="_blank" class="text-blue-400">${s.doi}</a></li>`).join('')+'</ul>';
    }
    if(e.target.id==='load-plant'){
      document.getElementById('plant-list').innerHTML='<ul class="space-y-2">'+sampleData.plantSample.map(s=>`<li class="p-3 bg-gray-800 rounded"><b>${s.title}</b><br/><span class="text-gray-400">${s.summary}</span><br/><a href="${s.doi}" target="_blank" class="text-blue-400">${s.doi}</a></li>`).join('')+'</ul>';
    }
  });
});
